# Developer: Attiqa Sheikh
# Filename: StateCapitals.py
# Purpose: displays all us states, and birds
def readSates(filename):
    states = []
    with open(filename) as f:
        for line in f:
            states.append(line.strip())  
    return states
def updateBird(state: str, newBird: str):
    parts = state.split(",")
    stateUpdated = parts[0] + "," + newBird
    return stateUpdated
def stateFlower(state: str, str, newFlower: str):
    parts = state.split(",")
    flowerUpdated = parts[1] + "," + newFlower
    return flowerUpdated
# prints the given state
def printState(state: str):
    print("US State: " + parts[0] + ", State Bird: " + parts[1], + "Flower: " + parts[2])

# Main method
def main():
    states = readSates("States.txt")
    print("Welcome to the US States Info System")
    print("-------------------------------------")
    while True:
        # Prints the menu
        print("\n1. Display all US States in Alphabetical Order Along with Capitals, Flower, and Bird")
        print("2. Search for specific State and Display Appropriate Capital")
        print("3. Update bird of specific State")
        print("4. Exit")
        op = int(input("Enter option: \n"))

        if op == 1:
            states.sort()
            print("US States: ")
            for s in states:
                printState(s)
        # If option 2, we ask for a state name
        elif op == 2:
            sn = input("Enter state name: ")
            found = False
            for s in states:
                if s.split(",")[0] == sn:
                    printState(s)
                    found = True
            if not found:
                print("State doesn't exist")
        elif op == 3:
            sn = input("Enter state name: ")
            found = False
            for i, s in enumerate(states):
                if s.split(",")[0] == sn:
                    newBird = input("Enter new bird: ")
                    updated = updateBird(s, newBird)
                    states[i] = updated
            if not found:
                print("State doesn't exist")
        elif op == 4:
            break
        else:
            continue

if __name__ == "__main__":
    main()