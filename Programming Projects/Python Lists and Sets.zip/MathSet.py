# Developer: Attiqa Sheikh
# Filename: Mathset.py
# Purpose: Determine the union, intersection and difference of the square and cube of integers
# ranging from 1 to 100
print("************************************************************************")
print("Welcome to the Math Set Application!")
menu = "1. Display the Square and Cube for Integers ranging from 1 to 100\n" \
       "2. Search the sets for a specific Integer and display the Square and Cube values \n" \
       "3. Display the Union of Square and Cube sets\n" \
       "4. Display the Intersection of Square and Cube sets\n" \
       "5. Display the Difference of Square and Cube sets\n" \
       "6. Exit the program\n" \
       "Enter your choice: "

#math operation for squares
squares = set([i*i for i in range(1, 101)])
#math operation for cubes
cubes = set([i*i*i for i in range(1, 101)])

option = int(input(menu))

while option != 6:
        #if the option is one, the following will occur
        if option == 1:
                print('squares: ', squares)
                print('cubes: ', cubes)
                print()
        #if option is 2, the following will occur
        elif option == 2:
                x = int(input('Enter integer to search: '))
                if x in squares:
                        print(x, 'is a square value.')
                else:
                        print(x, 'is not a square value.')
                if x in cubes:
                        print(x, 'is a cube value.')
                else:
                        print(x, 'is not a cube value.')
        #if option is 3,4,5,6, etc
        elif option == 3:
                print(squares.union(cubes))
        elif option == 4:
                print(squares.intersection(cubes))
        elif option == 5:
                print(squares.difference(cubes))
        elif option == 6:
                break
        else:
                print('Option is Invalid')
        print()
        option = int(input(menu))