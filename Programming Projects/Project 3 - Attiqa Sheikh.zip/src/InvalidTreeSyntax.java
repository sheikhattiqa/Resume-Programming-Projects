/*
 * Developer: Attiqa Sheikh
 * Date: June 25, 2020
 * File: InvalidTreeSyntax.java
 * Purpose: Defines a checked exception. Throws when invalid string
 * is supposed and Make Tree button is clicked
 */
public class InvalidTreeSyntax extends Exception {
	public InvalidTreeSyntax() {
		super();
	}
	public InvalidTreeSyntax(String message) {
		super(message);
	}
}
