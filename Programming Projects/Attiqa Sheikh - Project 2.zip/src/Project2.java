/*
 * Dev: Attiqa Sheikh
 * File: Project2.java
 * Date: June 15, 2020
 * Description: Main method
*/
import javax.swing.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class Project2 {
	private static List<Polynomial> polyList = new ArrayList<>();
	public static void main(String[] args) {
		processPolyList();
	}
	//fromFile method
	public static ArrayList<String> fromFile() {
		//Create ArrayList and JFileChooser
		ArrayList<String> expressionList = new ArrayList<>();
		JFileChooser chooser = new JFileChooser();
		//Show both directories and files
		chooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
		//use current directory for ease
		chooser.setCurrentDirectory(new File(System.getProperty("user.dir")));
		int response = chooser.showOpenDialog(null);
		if (response == JFileChooser.APPROVE_OPTION){
			File file = chooser.getSelectedFile();
			try {
				Scanner fileIn = new Scanner(file);
				if (file.isFile()){
					while (fileIn.hasNextLine()){
						String expression = fileIn.nextLine();
						expressionList.add(expression);
					}
				}
			}catch (NoSuchElementException nse){
				JOptionPane.showMessageDialog(JOptionPane.getRootFrame(),"File is Empty");
			}catch(FileNotFoundException fne){
				JOptionPane.showMessageDialog(JOptionPane.getRootFrame(),"File Not Found");
			}
		}
		return expressionList;
	}
	//checkWeakOrder method
	public static boolean checkWeakOrder( List<Polynomial> polyList){
		boolean isWeakOrder = true;
		Polynomial previous = polyList.get(polyList.size()-1);
		for(int i = polyList.size()-2; i > 0; i--){
			if (previous.compareExponents(polyList.get(i)) < 0){
				isWeakOrder = false;
			}
		}
		return isWeakOrder;
	}
	//processPolyList method
	public static void processPolyList(){
		try {
			ArrayList<String> a = fromFile();
			for (String element : a) {
				Polynomial p = new Polynomial(element);
				System.out.println(p);
				polyList.add(p);
			}
		}catch (InvalidPolynomialSyntax ex){
			JOptionPane.showMessageDialog(JOptionPane.getRootFrame(),ex.getMessage());
		}
		/* Call to check sorted for the Strong order check */
		System.out.println("Strong Ordered: " + OrderedList.checkSorted(polyList));
		/* Check for Weak order (exponents only) */
		System.out.println("Weak Ordered: " + checkWeakOrder(polyList));
	}
}
