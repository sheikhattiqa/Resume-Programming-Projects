/*
 * Dev: Attiqa Sheikh
 * File: InvalidPolynomialSyntax.java
 * Date: June 15, 2020
 * Description: Defines an unchecked exception
*/
public class InvalidPolynomialSyntax extends RuntimeException {
	InvalidPolynomialSyntax(String msg){
		super(msg);
	}
}
