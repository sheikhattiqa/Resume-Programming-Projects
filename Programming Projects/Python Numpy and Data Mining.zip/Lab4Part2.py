#Dev: Attiqa Sheikh
#Date: July 13, 2020
#Purpose: Create a program to enter and  store first name, last name, and zipcode of user/users

import re

def main():
  f = open("input.txt")
  flag = [0 for i in range(len(f))]

  for i in range(len(f)):
    #first name
    a = f[i][0]
    if re.match(r'[A-Za-z]+',a):
      flag[i] = 1
    else:
      f[i][0]=""
    #last name
    a = f[i][1]
    if re.match(r'[A-Za-z]+',a):
      flag[i] = 1
    else:
      f[i][1]=""
    #zip code
    a = f[i][2]
    if re.match(r'\d{5}[\-[0-9]{4}]?',a):
      flag[i] = 1
    else:
      f[i][2] = ""
    #Phone number
    a=f[i][3]
    re.sub("-","",a)
    if re.match(r'\d{10}',a):
      flag[i]=1
    else:
      f[i][3]=""
  print(f)
