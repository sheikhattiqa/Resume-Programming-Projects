# Dev: Attiqa Sheikh
# Date: July 13, 2020
# Purpose: Program that allows user to enter value of twos, 3x3 matrices and then
# select from options including addition, subtraction, matrix multiplication, and element
# by element multiplication

# importing numpy
import numpy as np

while True:
    print("Do you want to play the Matrix Game?")
    check = input("Enter Y for Yes and N for No \n")

    if check == "N":
        print("***********Thanks for playing Matrix Game*************")
        break

    if check == "Y":
        print("Enter your first matrix")
        M1 = []
        for i in range(3):
            r = [int(i) for i in input().strip().split(' ')]
            M1.append(r)
        M1 = np.array(M1)
        print("Your first 3x3 matrix is:")
        print(M1)
        print("Enter your second matrix")
        M2 = []
        for i in range(3):
            r = [int(i) for i in input().strip().split(' ')]
            M2.append(r)
        M2 = np.array(M2)
        print("Your second 3x3 matrix is:")
        print(M2)

        print("Select a matrix operation from below")
        print("a. Addition")
        print("b. Subraction")
        print("c. Matrix multiplication")
        print("d. Element by element multiplication")

        choice = input("")
        if choice == "a":
            ans = M1 + M2
            print("You selected addition. The results are:")
            print(ans)
            print("The transpose is:")
            print(ans.T)
            print("The row and column mean values are:")
            print("Row: ", np.mean(ans, axis=1))
            print("Column:", np.mean(ans, axis=0))
        elif choice == "b":
            ans = M1 - M2
            print("You selected subtraction. The results are:")
            print(ans)
            print("The transpose is:")
            print(ans.T)
            print("The row and column mean values are:")
            print("Row: ", np.mean(ans, axis=1))
            print("Column:", np.mean(ans, axis=0))
        elif choice == "c":
            ans = np.matmul(M1, M2)
            print("You selected Matrix Multiplication. The results are:")
            print(ans)
            print("The transpose is:")
            print(ans.T)
            print("The row and column mean values are:")
            print("Row: ", np.mean(ans, axis=1))
            print("Column:", np.mean(ans, axis=0))
        elif choice == "d":
            ans = M1 * M2
            print("You selected element wise multiplication. The results are: ", ans)
            print("The transpose is:")
            print(ans.T)
            print("The row and column mean values are:")
            print("Row: ", np.mean(ans, axis=1))
            print("Column:", np.mean(ans, axis=0))