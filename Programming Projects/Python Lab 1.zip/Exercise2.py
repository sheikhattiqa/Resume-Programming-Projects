import math #for the math terms
import numpy #loops over float valurs
import matplotlib.pyplot as plt #import to plot the graphs

def trigfunction():
    sin_y=[]
    cos_y=[]
    x_hold=[]
    for x in numpy.arange(-2*math.pi,2*math.pi,math.pi/64):
        x_hold.append(x)
        sin_y.append(math.sin(x))
        cos_y.append(math.cos(x))
    return x_hold, sin_y, cos_y

def algfunction():
    x_hold=[]
    sqrt_y=[]
    log_y=[0]
    for x in numpy.arange(0,200,0.5):
        x_hold.append(x)
        if(x == 0):
            sqrt_y.append(math.sqrt(x))
            continue
        sqrt_y.append(math.sqrt(x))
        log_y.append(math.log10(x))
    return x_hold, sqrt_y, log_y

#displaying values for trig functions
trigx,siny,cosy = trigfunction()
print("Value of x for trigo functions:", trigx)
print("\n")
print("Value of sin(f(x))", siny)
print("\n")
print("Value of cos(f(x))", cosy)
print("\n")

#display values for algebraic functions
algx,sqrty,logy = algfunction()
print("Value of x for algebaric functions:", algx)
print("\n")
print("Value of sqrt(f(x))", sqrty)
print("\n")
print("Value of log10(f(x))", logy)

#I've used matplotlib while teaching python at coder kids and i am really familiar with this
#I mostly used it for pre created tables and csv files but never for creating my own function and graphing
def graph():
    plt.subplot(2,1,1)
    plt.plot(trigx, siny,"b--", trigx, cosy,"c:")
    #label x, y, title, legend
    plt.xlabel('X Values (-2pi - 2pi)')
    plt.ylabel('sin(x) and cos(x)')
    plt.title('Sin and Cos (-2pi - 2pi)')
    plt.legend(['sin', 'cos'])
    plt.subplots_adjust(hspace = 0.6, wspace = 0.6)
    plt.subplot(2,1,2)
    plt.plot(algx,sqrty,"y-",algx,logy,"g-.")
    #labels, titles, legends
    plt.xlabel('X Values (0 to 200)')
    plt.ylabel('sqrt(x) and log10(x)')
    plt.title('Plot of Squareroot and log (0 to 200)')
    plt.legend(['sqrt', 'log10'])
    #displays the graph
    plt.show()
graph()