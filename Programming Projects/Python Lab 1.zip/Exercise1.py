#Developer: Attiqa Sheikh
#File: Exercise1.py
#Date: June 25, 2020
#Purpose: Generates lottery numbers allowing the user to pick
#between an array of 3 or 4
import random
#displays menu upon startup
def Menu():
    print("Menu List:\n"
          "1: Generate 3 digit lottery number \n"
          "2: Generate 4 digit lottery number \n"
          "3: Exit the application")
#welcome message
print("****Welcome to the Pick-3, Pick-4 lottery number generator****")
while True:
    Menu()
    menuChoice = input("Please enter your choice: \n")
    #if statement for menu choices
    if(menuChoice == "1"):
        pick3 = " "
        for i in range(0,3):
            rand = str(random.randint(0,9))
            pick3 = pick3 + rand;

        print("You selected 1. The following 3-digit lottery number was generated: ")
        print(pick3);
        print("")
    #if statement for choice 2
    elif(menuChoice == "2"):
        pick4 = ""
        for i in range(0,4):
            rand = str(random.randint(0,9))
            pick4 = pick4 + rand;
        print("You selected 2. The following 4 digit lottery number was generated: ")
        print(pick4);
        print("")
    #if statement for menu choice 3
    elif(menuChoice == "3"):
        print("You Selected 3. \n"
              "Thanks for trying the lottery application.\n"
              "********************************************")
        break;
    else:
    #if menu choice is not between 1-3 message is displayed
        print("Invalid input, try again")